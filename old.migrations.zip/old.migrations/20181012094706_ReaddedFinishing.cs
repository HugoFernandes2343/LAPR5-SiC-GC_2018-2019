﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SiC.Migrations
{
    public partial class ReaddedFinishing : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Category_Category_fatherCategoryId",
                table: "Category");

            migrationBuilder.DropForeignKey(
                name: "FK_Product_Dimension_dimensionsDimensionId",
                table: "Product");

            migrationBuilder.DropIndex(
                name: "IX_Product_dimensionsDimensionId",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "dimensionsDimensionId",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "finish",
                table: "Material");

            migrationBuilder.RenameColumn(
                name: "fatherCategoryId",
                table: "Category",
                newName: "parentCategoryId");

            migrationBuilder.RenameIndex(
                name: "IX_Category_fatherCategoryId",
                table: "Category",
                newName: "IX_Category_parentCategoryId");

            migrationBuilder.AddColumn<string>(
                name: "name",
                table: "Product",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "FinishingId",
                table: "Material",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "Dimension",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Finishing",
                columns: table => new
                {
                    FinishingId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    type = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Finishing", x => x.FinishingId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Material_FinishingId",
                table: "Material",
                column: "FinishingId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_ProductId",
                table: "Dimension",
                column: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_Category_Category_parentCategoryId",
                table: "Category",
                column: "parentCategoryId",
                principalTable: "Category",
                principalColumn: "CategoryId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Product_ProductId",
                table: "Dimension",
                column: "ProductId",
                principalTable: "Product",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Material_Finishing_FinishingId",
                table: "Material",
                column: "FinishingId",
                principalTable: "Finishing",
                principalColumn: "FinishingId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Category_Category_parentCategoryId",
                table: "Category");

            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Product_ProductId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Material_Finishing_FinishingId",
                table: "Material");

            migrationBuilder.DropTable(
                name: "Finishing");

            migrationBuilder.DropIndex(
                name: "IX_Material_FinishingId",
                table: "Material");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_ProductId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "name",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "FinishingId",
                table: "Material");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "Dimension");

            migrationBuilder.RenameColumn(
                name: "parentCategoryId",
                table: "Category",
                newName: "fatherCategoryId");

            migrationBuilder.RenameIndex(
                name: "IX_Category_parentCategoryId",
                table: "Category",
                newName: "IX_Category_fatherCategoryId");

            migrationBuilder.AddColumn<int>(
                name: "dimensionsDimensionId",
                table: "Product",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "finish",
                table: "Material",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Product_dimensionsDimensionId",
                table: "Product",
                column: "dimensionsDimensionId");

            migrationBuilder.AddForeignKey(
                name: "FK_Category_Category_fatherCategoryId",
                table: "Category",
                column: "fatherCategoryId",
                principalTable: "Category",
                principalColumn: "CategoryId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Product_Dimension_dimensionsDimensionId",
                table: "Product",
                column: "dimensionsDimensionId",
                principalTable: "Dimension",
                principalColumn: "DimensionId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
