﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SiC.Migrations
{
    public partial class MaterialFinishList : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Material_Finishing_FinishingId",
                table: "Material");

            migrationBuilder.DropIndex(
                name: "IX_Material_FinishingId",
                table: "Material");

            migrationBuilder.DropColumn(
                name: "FinishingId",
                table: "Material");

            migrationBuilder.AddColumn<int>(
                name: "MaterialId",
                table: "Finishing",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CategoryId",
                table: "Category",
                nullable: false,
                oldClrType: typeof(int))
                .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            migrationBuilder.AddColumn<int>(
                name: "parentCategoryId",
                table: "Category",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Finishing_MaterialId",
                table: "Finishing",
                column: "MaterialId");

            migrationBuilder.CreateIndex(
                name: "IX_Category_parentCategoryId",
                table: "Category",
                column: "parentCategoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_Category_Category_parentCategoryId",
                table: "Category",
                column: "parentCategoryId",
                principalTable: "Category",
                principalColumn: "CategoryId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Finishing_Material_MaterialId",
                table: "Finishing",
                column: "MaterialId",
                principalTable: "Material",
                principalColumn: "MaterialId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Category_Category_parentCategoryId",
                table: "Category");

            migrationBuilder.DropForeignKey(
                name: "FK_Finishing_Material_MaterialId",
                table: "Finishing");

            migrationBuilder.DropIndex(
                name: "IX_Finishing_MaterialId",
                table: "Finishing");

            migrationBuilder.DropIndex(
                name: "IX_Category_parentCategoryId",
                table: "Category");

            migrationBuilder.DropColumn(
                name: "MaterialId",
                table: "Finishing");

            migrationBuilder.DropColumn(
                name: "parentCategoryId",
                table: "Category");

            migrationBuilder.AddColumn<int>(
                name: "FinishingId",
                table: "Material",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "CategoryId",
                table: "Category",
                nullable: false,
                oldClrType: typeof(int))
                .OldAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            migrationBuilder.CreateIndex(
                name: "IX_Material_FinishingId",
                table: "Material",
                column: "FinishingId");

            migrationBuilder.AddForeignKey(
                name: "FK_Material_Finishing_FinishingId",
                table: "Material",
                column: "FinishingId",
                principalTable: "Finishing",
                principalColumn: "FinishingId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
