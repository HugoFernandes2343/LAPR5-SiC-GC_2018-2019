﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SiC.Migrations
{
    public partial class RestrictionDimUpdate3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<float>(
                name: "x",
                table: "Restriction",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "y",
                table: "Restriction",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "z",
                table: "Restriction",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "x",
                table: "Restriction");

            migrationBuilder.DropColumn(
                name: "y",
                table: "Restriction");

            migrationBuilder.DropColumn(
                name: "z",
                table: "Restriction");
        }
    }
}
