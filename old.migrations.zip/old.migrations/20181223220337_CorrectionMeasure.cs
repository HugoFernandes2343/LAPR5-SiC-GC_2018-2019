﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SiC.Migrations
{
    public partial class CorrectionMeasure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_DepthId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_HeightId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_WidthId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_DepthId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_HeightId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_WidthId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "DepthId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "HeightId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "WidthId",
                table: "Dimension");

            migrationBuilder.AddColumn<int>(
                name: "DepthMeasureId",
                table: "Dimension",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "HeightMeasureId",
                table: "Dimension",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "WidthMeasureId",
                table: "Dimension",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_DepthMeasureId",
                table: "Dimension",
                column: "DepthMeasureId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_HeightMeasureId",
                table: "Dimension",
                column: "HeightMeasureId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_WidthMeasureId",
                table: "Dimension",
                column: "WidthMeasureId");

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_DepthMeasureId",
                table: "Dimension",
                column: "DepthMeasureId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_HeightMeasureId",
                table: "Dimension",
                column: "HeightMeasureId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_WidthMeasureId",
                table: "Dimension",
                column: "WidthMeasureId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_DepthMeasureId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_HeightMeasureId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_WidthMeasureId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_DepthMeasureId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_HeightMeasureId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_WidthMeasureId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "DepthMeasureId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "HeightMeasureId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "WidthMeasureId",
                table: "Dimension");

            migrationBuilder.AddColumn<int>(
                name: "DepthId",
                table: "Dimension",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "HeightId",
                table: "Dimension",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "WidthId",
                table: "Dimension",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_DepthId",
                table: "Dimension",
                column: "DepthId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_HeightId",
                table: "Dimension",
                column: "HeightId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_WidthId",
                table: "Dimension",
                column: "WidthId");

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_DepthId",
                table: "Dimension",
                column: "DepthId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_HeightId",
                table: "Dimension",
                column: "HeightId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_WidthId",
                table: "Dimension",
                column: "WidthId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
