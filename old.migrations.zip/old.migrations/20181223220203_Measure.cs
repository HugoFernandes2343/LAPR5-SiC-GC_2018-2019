﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SiC.Migrations
{
    public partial class Measure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Finishing_Material_MaterialId",
                table: "Finishing");

            migrationBuilder.DropForeignKey(
                name: "FK_Material_Product_ProductId",
                table: "Material");

            migrationBuilder.DropIndex(
                name: "IX_Material_ProductId",
                table: "Material");

            migrationBuilder.DropIndex(
                name: "IX_Finishing_MaterialId",
                table: "Finishing");

            migrationBuilder.DropColumn(
                name: "containedMaterial",
                table: "Restriction");

            migrationBuilder.DropColumn(
                name: "containingMaterial",
                table: "Restriction");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "Material");

            migrationBuilder.DropColumn(
                name: "MaterialId",
                table: "Finishing");

            migrationBuilder.DropColumn(
                name: "height",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "length",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "maxHeight",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "maxLength",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "maxWidth",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "width",
                table: "Dimension");

            migrationBuilder.RenameColumn(
                name: "type",
                table: "Material",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "type",
                table: "Finishing",
                newName: "name");

            migrationBuilder.RenameColumn(
                name: "type",
                table: "Category",
                newName: "name");

            migrationBuilder.AddColumn<int>(
                name: "containedMaterialMaterialId",
                table: "Restriction",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "containingMaterialMaterialId",
                table: "Restriction",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "DepthId",
                table: "Dimension",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "HeightId",
                table: "Dimension",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "WidthId",
                table: "Dimension",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Measure",
                columns: table => new
                {
                    MeasureId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Value = table.Column<double>(nullable: false),
                    ValueMax = table.Column<double>(nullable: false),
                    isDiscrete = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Measure", x => x.MeasureId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Restriction_containedMaterialMaterialId",
                table: "Restriction",
                column: "containedMaterialMaterialId");

            migrationBuilder.CreateIndex(
                name: "IX_Restriction_containingMaterialMaterialId",
                table: "Restriction",
                column: "containingMaterialMaterialId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_DepthId",
                table: "Dimension",
                column: "DepthId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_HeightId",
                table: "Dimension",
                column: "HeightId");

            migrationBuilder.CreateIndex(
                name: "IX_Dimension_WidthId",
                table: "Dimension",
                column: "WidthId");

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_DepthId",
                table: "Dimension",
                column: "DepthId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_HeightId",
                table: "Dimension",
                column: "HeightId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Dimension_Measure_WidthId",
                table: "Dimension",
                column: "WidthId",
                principalTable: "Measure",
                principalColumn: "MeasureId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Restriction_Material_containedMaterialMaterialId",
                table: "Restriction",
                column: "containedMaterialMaterialId",
                principalTable: "Material",
                principalColumn: "MaterialId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Restriction_Material_containingMaterialMaterialId",
                table: "Restriction",
                column: "containingMaterialMaterialId",
                principalTable: "Material",
                principalColumn: "MaterialId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_DepthId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_HeightId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Dimension_Measure_WidthId",
                table: "Dimension");

            migrationBuilder.DropForeignKey(
                name: "FK_Restriction_Material_containedMaterialMaterialId",
                table: "Restriction");

            migrationBuilder.DropForeignKey(
                name: "FK_Restriction_Material_containingMaterialMaterialId",
                table: "Restriction");

            migrationBuilder.DropTable(
                name: "Measure");

            migrationBuilder.DropIndex(
                name: "IX_Restriction_containedMaterialMaterialId",
                table: "Restriction");

            migrationBuilder.DropIndex(
                name: "IX_Restriction_containingMaterialMaterialId",
                table: "Restriction");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_DepthId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_HeightId",
                table: "Dimension");

            migrationBuilder.DropIndex(
                name: "IX_Dimension_WidthId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "containedMaterialMaterialId",
                table: "Restriction");

            migrationBuilder.DropColumn(
                name: "containingMaterialMaterialId",
                table: "Restriction");

            migrationBuilder.DropColumn(
                name: "DepthId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "HeightId",
                table: "Dimension");

            migrationBuilder.DropColumn(
                name: "WidthId",
                table: "Dimension");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "Material",
                newName: "type");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "Finishing",
                newName: "type");

            migrationBuilder.RenameColumn(
                name: "name",
                table: "Category",
                newName: "type");

            migrationBuilder.AddColumn<int>(
                name: "containedMaterial",
                table: "Restriction",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "containingMaterial",
                table: "Restriction",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "Material",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MaterialId",
                table: "Finishing",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "height",
                table: "Dimension",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "length",
                table: "Dimension",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "maxHeight",
                table: "Dimension",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "maxLength",
                table: "Dimension",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "maxWidth",
                table: "Dimension",
                nullable: true);

            migrationBuilder.AddColumn<double>(
                name: "width",
                table: "Dimension",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.CreateIndex(
                name: "IX_Material_ProductId",
                table: "Material",
                column: "ProductId");

            migrationBuilder.CreateIndex(
                name: "IX_Finishing_MaterialId",
                table: "Finishing",
                column: "MaterialId");

            migrationBuilder.AddForeignKey(
                name: "FK_Finishing_Material_MaterialId",
                table: "Finishing",
                column: "MaterialId",
                principalTable: "Material",
                principalColumn: "MaterialId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Material_Product_ProductId",
                table: "Material",
                column: "ProductId",
                principalTable: "Product",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
