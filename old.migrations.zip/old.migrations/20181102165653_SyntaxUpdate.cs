﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SiC.Migrations
{
    public partial class SyntaxUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Product_Material_MaterialId",
                table: "Product");

            migrationBuilder.DropIndex(
                name: "IX_Product_MaterialId",
                table: "Product");

            migrationBuilder.DropColumn(
                name: "MaterialId",
                table: "Product");

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "Material",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Material_ProductId",
                table: "Material",
                column: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_Material_Product_ProductId",
                table: "Material",
                column: "ProductId",
                principalTable: "Product",
                principalColumn: "ProductId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Material_Product_ProductId",
                table: "Material");

            migrationBuilder.DropIndex(
                name: "IX_Material_ProductId",
                table: "Material");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "Material");

            migrationBuilder.AddColumn<int>(
                name: "MaterialId",
                table: "Product",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Product_MaterialId",
                table: "Product",
                column: "MaterialId");

            migrationBuilder.AddForeignKey(
                name: "FK_Product_Material_MaterialId",
                table: "Product",
                column: "MaterialId",
                principalTable: "Material",
                principalColumn: "MaterialId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
