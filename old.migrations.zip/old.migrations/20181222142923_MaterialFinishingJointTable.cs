﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SiC.Migrations
{
    public partial class MaterialFinishingJointTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MaterialFinishing",
                columns: table => new
                {
                    MaterialId = table.Column<int>(nullable: false),
                    FinishingId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MaterialFinishing", x => new { x.MaterialId, x.FinishingId });
                    table.ForeignKey(
                        name: "FK_MaterialFinishing_Finishing_FinishingId",
                        column: x => x.FinishingId,
                        principalTable: "Finishing",
                        principalColumn: "FinishingId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MaterialFinishing_Material_MaterialId",
                        column: x => x.MaterialId,
                        principalTable: "Material",
                        principalColumn: "MaterialId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MaterialFinishing_FinishingId",
                table: "MaterialFinishing",
                column: "FinishingId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MaterialFinishing");
        }
    }
}
